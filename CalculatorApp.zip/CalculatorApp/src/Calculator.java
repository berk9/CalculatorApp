public interface Calculator {

    void calculationOperations();
    void plusMinusOperation();
    void sqrtOperation();
    void percentOperation();
    void disableCommands();
    void enableCommands();

}
